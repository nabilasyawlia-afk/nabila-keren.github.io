<?php
    include "koneksi.php";
?>
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Register Perpustakaan Digital</title>
        <link href="css/styles.css" rel="stylesheet" />
        <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
    </head>
    <body class="bg-primary">
        <div id="layoutAuthentication">
            <div id="layoutAuthentication_content">
                <main>
                    <div class="container">
                        <div class="row justify-content-center">
                            <div class="col-lg-5">
                                <div class="card shadow-lg border-0 rounded-lg mt-5">
                                    <div class="card-header"><h3 class="text-center font-weight-light my-4">Register Perpustakaan Digital</h3></div>
                                    <div class="card-body">
                                        <?php
                                            if(isset($_POST['register'])) {
                                                
                                                    $nama = isset($_POST['nama']) ? $_POST['nama'] : '';
                                                    $email = isset($_POST['email']) ? $_POST['email'] : '';
                                                    $alamat = isset($_POST['alamat']) ? $_POST['alamat'] : '';
                                                    $no_telpon = $_POST['no_telepon'];
                                                    $username = $_POST['username'];
                                                    if (isset($_POST['password'])) {
                                                    $password = md5($_POST['password']);
                                                    $level = isset($_POST['level']) ? $_POST['level'] : '';

                                                    $insert = mysqli_query($koneksi, "INSERT INTO user(nama,email,alamat,no_telpon,username,password,level) VALUES('$nama','$email','$alamat','$no_telpon','$username','$password','$level')");

                                                    if($insert){
                                                        echo '<script>alert("Selamat! Register Berhasil."); location.href="login.php";</script>';
                                                    }else{
                                                        echo '<script>alert("Register gagal. Silahkan ulangi kembali!");</script>';
                                                    }
                                                }
                                            }
                                        ?>
                                        <form method="post">
                                            <div class="form-floating mb-3">
                                                <input class="form-control" type="text" required name="nama" placeholder="Masukan Nama lengkap" />
                                                <label>Nama Lengkap</label>
                                            </div>
                                            <div class="form-floating mb-3">
                                                <input class="form-control" type="text" required name="name" placeholder="Masukan Email" />
                                                <label>Email</label>
                                            </div>
                                            <div class="form-floating mb-3">
                                                <input class="form-control" type="username" required name="username" placeholder="Enter Username" />
                                                <label>Username</label>
                                            </div>
                                            <div class="form-floating mb-3">
                                                <input class="form-control" id="inputPassword" required type="password" name="password" placeholder="Enter Password" />
                                                <label for="inputPassword">Password</label>
                                            </div>
                                            <div class="form-floating mb-3">
                                                <input class="form-control" type="text" required name="no_telepon" placeholder="Masukan Nomor Telepon" />
                                                <label>Nomor Telepon</label>
                                            </div>
                                            <div class="form-floating mb-3">
                                                <textarea nama="alamat" row="5" class="form-control"></textarea>
                                                <label>Alamat Lengkap</label>
                                            </div>
                                            <div class="form-floating mb-3">
                                                <select nama="level" required class="form-select">
                                                    <option value="petugas">Petugas</option>
                                                    <option value="peminjam">Peminjam</option>
                                                </select>
                                                <label>Jabatan</label>
                                            </div>
                                            <div class="d-flex align-items-center justify-content-between mt-4 mb-0">
                                                <button class="btn btn-primary" type="submit" name="register" value="register">Register</button>
                                                <a class="btn btn-danger" href="login.php">Login</a>
                                            </div>
                                        </form>
                                    </div>
                                    <div class="card-footer text-center py-3">
                                        <div class="small">
                                            &copy; 2024 Perpustakaan Digital by Widodo
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </main>
            </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>
        <script src="js/scripts.js"></script>
    </body>
</html>